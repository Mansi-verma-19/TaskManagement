﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.Models;
using TaskManagementAPI.Services;


namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly ITaskService _taskService;

        public TasksController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet]
        public IActionResult GetAll([FromQuery] string? status, [FromQuery] DateTime? dueDate,
                                     [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            return Ok(_taskService.GetAllTasks(status, dueDate, pageNumber, pageSize));
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var task = _taskService.GetTaskById(id).Result;
            if (task == null) return NotFound();
            return Ok(task);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Models.Task task)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var createdTask = _taskService.Create(task).Result;
            return CreatedAtAction(nameof(GetById), new { id = createdTask.Id }, createdTask);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Models.Task task)
        {
            var updatedTask = _taskService.UpdateTask(id, task).Result;
            if (updatedTask == null) return NotFound();
            return Ok(updatedTask);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var isDeleted = _taskService.DeleteTask(id).Result;
            if (!isDeleted) return NotFound();
            return NoContent();
        }
    }
}
