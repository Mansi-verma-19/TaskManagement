﻿using ModelsTask = TaskManagementAPI.Models.Task;
namespace TaskManagementAPI.Services

{
    public interface ITaskService
    {
        

        IEnumerable<ModelsTask> GetAllTasks(string? status, DateTime? dueDate, int pageNumber, int pageSize);
        Task<ModelsTask?> GetTaskById(int id);
        Task<ModelsTask?> UpdateTask(int id, ModelsTask task);
        Task<bool> DeleteTask(int id);
        Task<ModelsTask> Create(ModelsTask task);
        
    }
}

