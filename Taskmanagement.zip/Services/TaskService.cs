﻿using Microsoft.EntityFrameworkCore;
using TaskManagementAPI.Data;
using ModelsTask = TaskManagementAPI.Models.Task;

namespace TaskManagementAPI.Services
{
    public class TaskService : ITaskService
    {
        private readonly AppDbContext _context;

        public TaskService(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<ModelsTask> GetAllTasks(string? status, DateTime? dueDate, int pageNumber, int pageSize)
        {
            var query = _context.Tasks.AsQueryable();

            if (!string.IsNullOrEmpty(status) &&
                Enum.TryParse<TaskManagementAPI.Models.TaskStatus>(status, true, out var parsedStatus))
            {
                query = query.Where(t => t.Status == parsedStatus);
            }

            if (dueDate.HasValue)
            {
                query = query.Where(t => t.DueDate <= dueDate.Value);
            }

            return query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }


        public async Task<ModelsTask?> GetTaskById(int id) => await _context.Tasks.FindAsync(id);


        public async Task<ModelsTask> Create(ModelsTask task)
        {
            _context.Tasks.Add(task);
            await _context.SaveChangesAsync();
            return task;
        }

        public async Task<ModelsTask?> UpdateTask(int id, ModelsTask task)
        {
            var existingTask = await _context.Tasks.FindAsync(id);
            if (existingTask == null) return null;

            existingTask.Title = task.Title;
            existingTask.Description = task.Description;
            existingTask.Status = task.Status;
            existingTask.DueDate = task.DueDate;

            await _context.SaveChangesAsync();
            return existingTask;
        }

        public async Task<bool> DeleteTask(int id)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return false;

            _context.Tasks.Remove(task);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
